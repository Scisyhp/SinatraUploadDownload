/*
//Name: ________
//Program: program18_26.cpp
//Purpose: to decrypt rot13 using frequency substitution
//Date: 
//Date Modified: everyday
*/

#include<iostream>
#include<iomanip>
#include<cstdlib>
#include<ctime>
#include<string>
#include<fstream>
#include<cstring>
using namespace std;

int decrypt(int length, string word)
{
int freq[26];
int a = 0;
int b = 0;
int c = 0;
int d = 0;
int e = 0;
int f = 0;
int g = 0;
int h = 0;
int i = 0;
int j = 0;
int k = 0;
int l = 0;
int m = 0;
int n = 0;
int o = 0;
int p = 0;
int q = 0;
int r = 0;
int s = 0;
int t = 0;
int u = 0;
int v = 0;
int w = 0;
int x = 0;
int y = 0;
int z = 0;
int place_a = 0;
int place_b = 0;
int place_c = 0;
int place_d = 0;
int place_e = 0;
int place_f = 0;
int place_g = 0;
int place_h = 0;
int place_i = 0;
int place_j = 0;
int place_k = 0;
int place_l = 0;
int place_m = 0;
int place_n = 0;
int place_o = 0;
int place_p = 0;
int place_q = 0;
int place_r = 0;
int place_s = 0;
int place_t = 0;
int place_u = 0;
int place_v = 0;
int place_w = 0;
int place_x = 0;
int place_y = 0;
int place_z = 0;
char commoneng[26] = {'e', 't', 'a', 'o', 'i', 'n', 's', 'r', 'h', 'l', 'd', 'c', 'u', 'm', 'f', 'p', 'g', 'w', 'y', 'b', 'v', 'k', 'x', 'j', 'q', 'z'};



   
    
    
        // gets the frequencies and fills each respective array with the place each letter is found
        for(int it = 0; it < length; it++)
        {
            if(word[it] == 'a')
            {
                a++;       
            }
            else if( word[it] == 'b')
            {
                b++;
            }
            else if( word[it] == 'c')
            {
                c++;
            }
            else if( word[it] == 'd')
            {
                d++;               
            }
            else if( word[it] == 'e')
            {
                e++;
            }
            else if( word[it] == 'f')
            {
                f++;
            }
            else if( word[it] == 'g')
            {
                g++;
            }
            else if( word[it] == 'h')
            {
                h++;
            }
            else if( word[it] == 'i')
            {
                i++;
            }
            else if( word[it] == 'j')
            {
                j++;
            }
            else if( word[it] == 'k')
            {
                k++;
            }
            else if( word[it] == 'l')
            {
                l++; 
            }
            else if( word[it] == 'm')
            {
                m++;
            }
            else if( word[it] == 'n')
            {
                n++;
            }
            else if( word[it] == 'o')
            {
                o++;
            }
            else if( word[it] == 'p')
            {
                p++;
            }
            else if( word[it] == 'q')
            {
                q++;
            }
            else if( word[it] == 'r')
            {
                r++;
            }
            else if( word[it] == 's')
            {
                s++;
            }
            else if( word[it] == 't')
            {
                t++;
            }
            else if( word[it] == 'u')
            {
                u++;
            }
            else if( word[it] == 'v')
            {
                v++;
            }
            else if( word[it] == 'w')
            {
                w++;
            }
            else if( word[it] == 'x')
            {
                x++;
            }
            else if( word[it] == 'y')
            {
                y++;
            }    
            else if( word[it] == 'z')
            {
                z++; 
            }
        }// end for
        
 //makes arrays for each letter with the restrictions of the frequencies of each letter       
int a_array[a];
int b_array[b];
int c_array[c];
int d_array[d];
int e_array[e];
int f_array[f];
int g_array[g];
int h_array[h];
int i_array[i];
int j_array[j];
int k_array[k];
int l_array[l];
int m_array[m];
int n_array[n];
int o_array[o];
int p_array[p];
int q_array[q];
int r_array[r];
int s_array[s];
int t_array[t];
int u_array[u];
int v_array[v];
int w_array[w];
int x_array[x];
int y_array[y];
int z_array[z];


        // gets the place of the letters in the input and puts them into an array
        for(int mm = 0; mm < length; mm++)
        {
        
            if(word[mm] == 'a')
            {
                if(place_a < length)
                {
                 a_array[place_a] = mm;
                 place_a++;
                }        
            }
            else if( word[mm] == 'b')
            {
                if(place_b < length)
                {
                 b_array[place_b] = mm;
                 place_b++;
                }
            }
            else if( word[mm] == 'c')
            {
                if(place_c < length)
                {
                 c_array[place_c] = mm;
                 place_c++;
                }
            }
            else if( word[mm] == 'd')
            {
                if(place_d < length)
                {
                 d_array[place_d] = mm;
                 place_d++;
                }                
            }
            else if( word[mm] == 'e')
            {
                if(place_e < length)
                {
                 e_array[place_e] = mm;
                 place_e++;
                } 
            }
            else if( word[mm] == 'f')
            {
                if(place_f < length)
                {
                 f_array[place_f] = mm;
                 place_f++;
                } 
            }
            else if( word[mm] == 'g')
            {
                if(place_g < length)
                {
                 g_array[place_g] = mm;
                 place_g++;
                } 
            }
            else if( word[mm] == 'h')
            {
                if(place_h < length)
                {
                 h_array[place_h] = mm;
                 place_h++;
                } 
            }
            else if( word[mm] == 'i')
            {
                if(place_i < length)
                {
                 i_array[place_i] = mm;
                 place_i++;
                } 
            }
            else if( word[mm] == 'j')
            {
                if(place_j < length)
                {
                 j_array[place_j] = mm;
                 place_j++;
                } 
            }
            else if( word[mm] == 'k')
            {
                if(place_k < length)
                {
                 k_array[place_k] = mm;
                 place_k++;
                } 
            }
            else if( word[mm] == 'l')
            {
                if(place_l < length)
                {
                 l_array[place_l] = mm;
                 place_l++;
                } 
            }
            else if( word[mm] == 'm')
            {
                if(place_m < length)
                {
                 m_array[place_m] = mm;
                 place_m++;
                } 
            }
            else if( word[mm] == 'n')
            {
                if(place_n < length)
                {
                 n_array[place_n] = mm;
                 place_n++;
                } 
            }
            else if( word[mm] == 'o')
            {
                if(place_o < length)
                {
                 o_array[place_p] = mm;
                 place_o++;
                } 
            }
            else if( word[mm] == 'p')
            {
                if(place_p < length)
                {
                 p_array[place_p] = mm;
                 place_p++;
                } 
            }
            else if( word[mm] == 'q')
            {
                if(place_q < length)
                {
                 q_array[place_q] = mm;
                 place_q++;
                } 
            }
            else if( word[mm] == 'r')
            {
                if(place_r < length)
                {
                 r_array[place_r] = mm;
                 place_r++;
                } 
            }
            else if( word[mm] == 's')
            {
                if(place_s < length)
                {
                 s_array[place_s] = mm;
                 place_s++;
                } 
            }
            else if( word[mm] == 't')
            {
                if(place_t < length)
                {
                 t_array[place_t] = mm;
                 place_t++;
                } 
            }
            else if( word[mm] == 'u')
            {
                if(place_u < length)
                {
                 u_array[place_u] = mm;
                 place_u++;
                } 
            }
            else if( word[mm] == 'v')
            {
                if(place_v < length)
                {
                 v_array[place_v] = mm;
                 place_v++;
                } 
            }
            else if( word[mm] == 'w')
            {
                if(place_w < length)
                {
                 w_array[place_w] = mm;
                 place_w++;
                } 
            }
            else if( word[mm] == 'x')
            {
                if(place_x < length)
                {
                 x_array[place_x] = mm;
                 place_x++;
                } 
            }
            else if( word[mm] == 'y')
            {
                if(place_y < length)
                {
                 y_array[place_y] = mm;
                 place_y++;
                } 
            }    
            else if( word[mm] == 'z')
            {
                if(place_z < length)
                {
                 z_array[place_z] = mm;
                 place_z++;
                } 
            }
        }// end for
        
        

// fills array with frequencies

    freq[0] = a;
    freq[1] = b;
    freq[2] = c;
    freq[3] = d;
    freq[4] = e;
    freq[5] = f;
    freq[6] = g;
    freq[7] = h;
    freq[8] = i;
    freq[9] = j;
    freq[10] = k;
    freq[11] = l;
    freq[12] = m;
    freq[13] = n;
    freq[14] = o;
    freq[15] = p;
    freq[16] = q;
    freq[17] = r;
    freq[18] = s;
    freq[19] = t;
    freq[20] = u;
    freq[21] = v;
    freq[22] = w;
    freq[23] = x;
    freq[24] = y;
    freq[25] = z;


//decreasing order of array
int pass, num, temp;
for(pass=0; pass<(sizeof(freq)/sizeof(int)); pass++)
for(num=0; num<(sizeof(freq)/sizeof(int))-1; num++)
if(freq[num] < freq[num+1])
{
temp=freq[num];
freq[num]=freq[num+1];
freq[num+1]=temp;
}


// the letters
char leta = 'a';
char letb = 'b';
char letc = 'c';
char letd = 'd';
char lete = 'e';
char letf = 'f';
char letg = 'g';
char leth = 'h';
char leti = 'i';
char letj = 'j';
char letk = 'k';
char letl = 'l';
char letm = 'm';
char letn = 'n';
char leto = 'o';
char letp = 'p';
char letq = 'q';
char letr = 'r';
char lets = 's';
char lett = 't';
char letu = 'u';
char letv = 'v';
char letw = 'w';
char letx = 'x';
char lety = 'y';
char letz = 'z';
char let[26];


//outputs the highest frequencies in order only if it is greater than 0
for( int baa = 0; baa < 26; baa++)
{
     if(freq[baa] > 0)
     {
        if(a == freq[baa])
        {
         let[baa] = leta;
         cout << leta << ' ';
         a = 199;
        }
        else if(b == freq[baa])
        {
         let[baa] = letb;
         cout << letb << ' '; 
         b = 199;   
        }
        else if(c == freq[baa])
        {
         let[baa] = letc;
         cout<< letc << ' ';
         c = 199;
        }
        else if(d == freq[baa])
        {
         let[baa] = letd;
         cout<< letd << ' ';
         d = 199;
        }
        else if(e == freq[baa])
        {
         let[baa] = lete;
         cout<< lete << ' ';
         e = 199;    
        }
        else if(f == freq[baa])
        {
         let[baa] = letf;
         cout<< letf << ' ';
         f= 199;
        }
        else if(g == freq[baa])
        {
         let[baa] = letg;
         cout<< letg << ' ';
         g = 199;
        }
        else if(h == freq[baa])
        {
         let[baa] = leth;
         cout<< leth << ' ';
         h = 199;
        }
        else if(i == freq[baa])
        {
         let[baa] = leti;
         cout<< leti << ' ';
         i = 199;
        }
        else if(j == freq[baa])
        {
         let[baa] = letj;
         cout<< letj << ' ';
         j= 199;
        }
        else if(k == freq[baa])
        {
         let[baa] = letk;
         cout<< letk << ' ';
         k = 199;
        }
        else if(l == freq[baa])
        {
         let[baa] = letl;
         cout<< letl << ' ';
         l = 199;
        }
        else if(m == freq[baa])
        {
         let[baa] = letm;
         cout<< letm << ' ';
         m= 199;
        }
        else if(n == freq[baa])
        {
         let[baa] = letn;
         cout<< letn << ' ';
         n = 199;
        }
        else if(o == freq[baa])
        {
         let[baa] = leto;
         cout<< leto << ' ';
         o == 199;
        }
        else if(p == freq[baa])
        {
         let[baa] = letp;
         cout<< letp << ' ';
         p == 199;
        }
        else if(q == freq[baa])
        {
         let[baa] = letq;
         cout<< letq << ' ';
         q == 199;
        }
        else if(r == freq[baa])
        {
         let[baa] = letr;
         cout<< letr << ' ';
         r == 199;
        }
        else if(s == freq[baa])
        {
         let[baa] = lets;
         cout<< lets << ' ';
         s == 199;
        }
        else if(t == freq[baa])
        {
         let[baa] = lett;
         cout<< lett << ' ';
         t == 199;
        }
        else if(u == freq[baa])
        {
         let[baa] = letu;
         cout<< letu << ' ';
         u == 199;
        }
        else if(v == freq[baa])
        {
         let[baa] = letv;
         cout<< letv << ' ';
         v == 199;
        }
        else if(w == freq[baa])
        {
         let[baa] = letw;
         cout<< letw << ' ';
         w == 199;
        }
        else if(x == freq[baa])
        {
         let[baa] = letx;
         cout<< letx << ' ';
         x == 199;
        }
        else if(y == freq[baa])
        {
         let[baa] = lety;
         cout<< lety << ' ';
         y == 99;
        }
        else if(z == freq[baa])
        {
         let[baa] = letz;
         cout<< letz << ' ';
         z == 99;
        }
     }// end if

}// end for


//rdecrypting here
int response;
cout << "Do you want to decrypt? (1 yes, 2 no)\n=> ";
cin>> response;


// makes a while loop that continuously decrypts the input(word) until the user says to stop
do
{
     
// all of these for loops and if/else if statements are to replace the most frequent letters of this unknown language with the most frequent english letters
// all of this could be easily replaced with something simpler but I do not know how to do that     
     for(int le = 0; le < a; le++)
     {
        if(let[0] == 'a')
        {
         word[a_array[le]] = commoneng[0];
        }      
        else if(let[1] == 'a')
        {
         word[a_array[le]] = commoneng[1];
        }
        else if(let[2] == 'a')
        {
         word[a_array[le]] = commoneng[2];
        }
        else if(let[3] == 'a')
        {
         word[a_array[le]] = commoneng[3];
        }
        else if(let[4] == 'a')
        {
         word[a_array[le]] = commoneng[4];
        }
        else if(let[5] == 'a')
        {
         word[a_array[le]] = commoneng[5];
        }
        else if(let[6] == 'a')
        {
         word[a_array[le]] = commoneng[6];
        }
        else if(let[7] == 'a')
        {
         word[a_array[le]] = commoneng[7];
        }
        else if(let[8] == 'a')
        {
         word[a_array[le]] = commoneng[8];
        }
        else if(let[9] == 'a')
        {
         word[a_array[le]] = commoneng[9];
        }
        else if(let[10] == 'a')
        {
         word[a_array[le]] = commoneng[10];
        }
        else if(let[11] == 'a')
        {
         word[a_array[le]] = commoneng[11];
        }
        else if(let[12] == 'a')
        {
         word[a_array[le]] = commoneng[12];
        }
        else if(let[13] == 'a')
        {
         word[a_array[le]] = commoneng[13];
        }
        else if(let[14] == 'a')
        {
         word[a_array[le]] = commoneng[14];
        }
        else if(let[15] == 'a')
        {
         word[a_array[le]] = commoneng[15];
        }
        else if(let[16] == 'a')
        {
         word[a_array[le]] = commoneng[16];
        }
        else if(let[17] == 'a')
        {
         word[a_array[le]] = commoneng[17];
        }
        else if(let[18] == 'a')
        {
         word[a_array[le]] = commoneng[18];
        }
        else if(let[19] == 'a')
        {
         word[a_array[le]] = commoneng[19];
        }
        else if(let[20] == 'a')
        {
         word[a_array[le]] = commoneng[20];
        }
        else if(let[21] == 'a')
        {
         word[a_array[le]] = commoneng[21];
        }
        else if(let[22] == 'a')
        {
         word[a_array[le]] = commoneng[22];
        }
        else if(let[23] == 'a')
        {
         word[a_array[le]] = commoneng[23];
        }
        else if(let[24] == 'a')
        {
         word[a_array[le]] = commoneng[24];
        }
        else if(let[25] == 'a')
        {
         word[a_array[le]] = commoneng[25];
        }
     }// end for
     for(int bm = 0; bm < b; bm++)
     {
        if(let[0] == 'b')
        {
         word[b_array[bm]] = commoneng[0];
        }      
        else if(let[1] == 'b')
        {
         word[b_array[bm]] = commoneng[1];
        }
        else if(let[2] == 'b')
        {
         word[b_array[bm]] = commoneng[2];
        }
        else if(let[3] == 'b')
        {
         word[b_array[bm]] = commoneng[3];
        }
        else if(let[4] == 'b')
        {
         word[b_array[bm]] = commoneng[4];
        }
        else if(let[5] == 'b')
        {
         word[b_array[bm]] = commoneng[5];
        }
        else if(let[6] == 'b')
        {
         word[b_array[bm]] = commoneng[6];
        }
        else if(let[7] == 'b')
        {
         word[b_array[bm]] = commoneng[7];
        }
        else if(let[8] == 'b')
        {
         word[b_array[bm]] = commoneng[8];
        }
        else if(let[9] == 'b')
        {
         word[b_array[bm]] = commoneng[9];
        }
        else if(let[10] == 'b')
        {
         word[b_array[bm]] = commoneng[10];
        }
        else if(let[11] == 'b')
        {
         word[b_array[bm]] = commoneng[11];
        }
        else if(let[12] == 'b')
        {
         word[b_array[bm]] = commoneng[12];
        }
        else if(let[13] == 'b')
        {
         word[b_array[bm]] = commoneng[13];
        }
        else if(let[14] == 'b')
        {
         word[b_array[bm]] = commoneng[14];
        }
        else if(let[15] == 'b')
        {
         word[b_array[bm]] = commoneng[15];
        }
        else if(let[16] == 'b')
        {
         word[b_array[bm]] = commoneng[16];
        }
        else if(let[17] == 'b')
        {
         word[b_array[bm]] = commoneng[17];
        }
        else if(let[18] == 'b')
        {
         word[b_array[bm]] = commoneng[18];
        }
        else if(let[19] == 'b')
        {
         word[b_array[bm]] = commoneng[19];
        }
        else if(let[20] == 'b')
        {
         word[b_array[bm]] = commoneng[20];
        }
        else if(let[21] == 'b')
        {
         word[b_array[bm]] = commoneng[21];
        }
        else if(let[22] == 'b')
        {
         word[b_array[bm]] = commoneng[22];
        }
        else if(let[23] == 'b')
        {
         word[b_array[bm]] = commoneng[23];
        }
        else if(let[24] == 'b')
        {
         word[b_array[bm]] = commoneng[24];
        }
        else if(let[25] == 'b')
        {
         word[b_array[bm]] = commoneng[25];
        }
     }// end for
     for(int bp = 0; bp < c; bp++)
     {
        if(let[0] == 'c')
        {
         word[c_array[bp]] = commoneng[0];
        }      
        else if(let[1] == 'c')
        {
         word[c_array[bp]] = commoneng[1];
        }
        else if(let[2] == 'c')
        {
         word[c_array[bp]] = commoneng[2];
        }
        else if(let[3] == 'c')
        {
         word[c_array[bp]] = commoneng[3];
        }
        else if(let[4] == 'c')
        {
         word[c_array[bp]] = commoneng[4];
        }
        else if(let[5] == 'c')
        {
         word[c_array[bp]] = commoneng[5];
        }
        else if(let[6] == 'c')
        {
         word[c_array[bp]] = commoneng[6];
        }
        else if(let[7] == 'c')
        {
         word[c_array[bp]] = commoneng[7];
        }
        else if(let[8] == 'c')
        {
         word[c_array[bp]] = commoneng[8];
        }
        else if(let[9] == 'c')
        {
         word[c_array[bp]] = commoneng[9];
        }
        else if(let[10] == 'c')
        {
         word[c_array[bp]] = commoneng[10];
        }
        else if(let[11] == 'c')
        {
         word[c_array[bp]] = commoneng[11];
        }
        else if(let[12] == 'c')
        {
         word[c_array[bp]] = commoneng[12];
        }
        else if(let[13] == 'c')
        {
         word[c_array[bp]] = commoneng[13];
        }
        else if(let[14] == 'c')
        {
         word[c_array[bp]] = commoneng[14];
        }
        else if(let[15] == 'c')
        {
         word[c_array[bp]] = commoneng[15];
        }
        else if(let[16] == 'c')
        {
         word[c_array[bp]] = commoneng[16];
        }
        else if(let[17] == 'c')
        {
         word[c_array[bp]] = commoneng[17];
        }
        else if(let[18] == 'c')
        {
         word[c_array[bp]] = commoneng[18];
        }
        else if(let[19] == 'c')
        {
         word[c_array[bp]] = commoneng[19];
        }
        else if(let[20] == 'c')
        {
         word[c_array[bp]] = commoneng[20];
        }
        else if(let[21] == 'c')
        {
         word[c_array[bp]] = commoneng[21];
        }
        else if(let[22] == 'c')
        {
         word[c_array[bp]] = commoneng[22];
        }
        else if(let[23] == 'c')
        {
         word[c_array[bp]] = commoneng[23];
        }
        else if(let[24] == 'c')
        {
         word[c_array[bp]] = commoneng[24];
        }
        else if(let[25] == 'c')
        {
         word[c_array[bp]] = commoneng[25];
        }
     }// end for
     for(int mk = 0; mk < d; mk++)
     {
        if(let[0] == 'd')
        {
         word[d_array[mk]] = commoneng[0];
        }      
        else if(let[1] == 'd')
        {
         word[d_array[mk]] = commoneng[1];
        }
        else if(let[2] == 'd')
        {
         word[d_array[mk]] = commoneng[2];
        }
        else if(let[3] == 'd')
        {
         word[d_array[mk]] = commoneng[3];
        }
        else if(let[4] == 'd')
        {
         word[d_array[mk]] = commoneng[4];
        }
        else if(let[5] == 'd')
        {
         word[d_array[mk]] = commoneng[5];
        }
        else if(let[6] == 'd')
        {
         word[d_array[mk]] = commoneng[6];
        }
        else if(let[7] == 'd')
        {
         word[d_array[mk]] = commoneng[7];
        }
        else if(let[8] == 'd')
        {
         word[d_array[mk]] = commoneng[8];
        }
        else if(let[9] == 'd')
        {
         word[d_array[mk]] = commoneng[9];
        }
        else if(let[10] == 'd')
        {
         word[d_array[mk]] = commoneng[10];
        }
        else if(let[11] == 'd')
        {
         word[d_array[mk]] = commoneng[11];
        }
        else if(let[12] == 'd')
        {
         word[d_array[mk]] = commoneng[12];
        }
        else if(let[13] == 'd')
        {
         word[d_array[mk]] = commoneng[13];
        }
        else if(let[14] == 'd')
        {
         word[d_array[mk]] = commoneng[14];
        }
        else if(let[15] == 'd')
        {
         word[d_array[mk]] = commoneng[15];
        }
        else if(let[16] == 'd')
        {
         word[d_array[mk]] = commoneng[16];
        }
        else if(let[17] == 'd')
        {
         word[d_array[mk]] = commoneng[17];
        }
        else if(let[18] == 'd')
        {
         word[d_array[mk]] = commoneng[18];
        }
        else if(let[19] == 'd')
        {
         word[d_array[mk]] = commoneng[19];
        }
        else if(let[20] == 'd')
        {
         word[d_array[mk]] = commoneng[20];
        }
        else if(let[21] == 'd')
        {
         word[d_array[mk]] = commoneng[21];
        }
        else if(let[22] == 'd')
        {
         word[d_array[mk]] = commoneng[22];
        }
        else if(let[23] == 'd')
        {
         word[d_array[mk]] = commoneng[23];
        }
        else if(let[24] == 'd')
        {
         word[d_array[mk]] = commoneng[24];
        }
        else if(let[25] == 'd')
        {
         word[d_array[mk]] = commoneng[25];
        }
     }// end for
     for(int tr = 0; tr < e; tr++)
     {
        if(let[0] == 'e')
        {
         word[e_array[tr]] = commoneng[0];
        }      
        else if(let[1] == 'e')
        {
         word[e_array[tr]] = commoneng[1];
        }
        else if(let[2] == 'e')
        {
         word[e_array[tr]] = commoneng[2];
        }
        else if(let[3] == 'e')
        {
         word[e_array[tr]] = commoneng[3];
        }
        else if(let[4] == 'e')
        {
         word[e_array[tr]] = commoneng[4];
        }
        else if(let[5] == 'e')
        {
         word[e_array[tr]] = commoneng[5];
        }
        else if(let[6] == 'e')
        {
         word[e_array[tr]] = commoneng[6];
        }
        else if(let[7] == 'e')
        {
         word[e_array[tr]] = commoneng[7];
        }
        else if(let[8] == 'e')
        {
         word[e_array[tr]] = commoneng[8];
        }
        else if(let[9] == 'e')
        {
         word[e_array[tr]] = commoneng[9];
        }
        else if(let[10] == 'e')
        {
         word[e_array[tr]] = commoneng[10];
        }
        else if(let[11] == 'e')
        {
         word[e_array[tr]] = commoneng[11];
        }
        else if(let[12] == 'e')
        {
         word[e_array[tr]] = commoneng[12];
        }
        else if(let[13] == 'e')
        {
         word[e_array[tr]] = commoneng[13];
        }
        else if(let[14] == 'e')
        {
         word[e_array[tr]] = commoneng[14];
        }
        else if(let[15] == 'e')
        {
         word[e_array[tr]] = commoneng[15];
        }
        else if(let[16] == 'e')
        {
         word[e_array[tr]] = commoneng[16];
        }
        else if(let[17] == 'e')
        {
         word[e_array[tr]] = commoneng[17];
        }
        else if(let[18] == 'e')
        {
         word[e_array[tr]] = commoneng[18];
        }
        else if(let[19] == 'e')
        {
         word[e_array[tr]] = commoneng[19];
        }
        else if(let[20] == 'e')
        {
         word[e_array[tr]] = commoneng[20];
        }
        else if(let[21] == 'e')
        {
         word[e_array[tr]] = commoneng[21];
        }
        else if(let[22] == 'e')
        {
         word[e_array[tr]] = commoneng[22];
        }
        else if(let[23] == 'e')
        {
         word[e_array[tr]] = commoneng[23];
        }
        else if(let[24] == 'e')
        {
         word[e_array[tr]] = commoneng[24];
        }
        else if(let[25] == 'e')
        {
         word[e_array[tr]] = commoneng[25];
        }
     }// end for
     for(int bz = 0; bz < f; bz++)
     {
        if(let[0] == 'f')
        {
         word[f_array[bz]] = commoneng[0];
        }      
        else if(let[1] == 'f')
        {
         word[f_array[bz]] = commoneng[1];
        }
        else if(let[2] == 'f')
        {
         word[f_array[bz]] = commoneng[2];
        }
        else if(let[3] == 'f')
        {
         word[f_array[bz]] = commoneng[3];
        }
        else if(let[4] == 'f')
        {
         word[f_array[bz]] = commoneng[4];
        }
        else if(let[5] == 'f')
        {
         word[f_array[bz]] = commoneng[5];
        }
        else if(let[6] == 'f')
        {
         word[f_array[bz]] = commoneng[6];
        }
        else if(let[7] == 'f')
        {
         word[f_array[bz]] = commoneng[7];
        }
        else if(let[8] == 'f')
        {
         word[f_array[bz]] = commoneng[8];
        }
        else if(let[9] == 'f')
        {
         word[f_array[bz]] = commoneng[9];
        }
        else if(let[10] == 'f')
        {
         word[f_array[bz]] = commoneng[10];
        }
        else if(let[11] == 'f')
        {
         word[f_array[bz]] = commoneng[11];
        }
        else if(let[12] == 'f')
        {
         word[f_array[bz]] = commoneng[12];
        }
        else if(let[13] == 'f')
        {
         word[f_array[bz]] = commoneng[13];
        }
        else if(let[14] == 'f')
        {
         word[f_array[bz]] = commoneng[14];
        }
        else if(let[15] == 'f')
        {
         word[f_array[bz]] = commoneng[15];
        }
        else if(let[16] == 'f')
        {
         word[f_array[bz]] = commoneng[16];
        }
        else if(let[17] == 'f')
        {
         word[f_array[bz]] = commoneng[17];
        }
        else if(let[18] == 'f')
        {
         word[f_array[bz]] = commoneng[18];
        }
        else if(let[19] == 'f')
        {
         word[f_array[bz]] = commoneng[19];
        }
        else if(let[20] == 'f')
        {
         word[f_array[bz]] = commoneng[20];
        }
        else if(let[21] == 'f')
        {
         word[f_array[bz]] = commoneng[21];
        }
        else if(let[22] == 'f')
        {
         word[f_array[bz]] = commoneng[22];
        }
        else if(let[23] == 'f')
        {
         word[f_array[bz]] = commoneng[23];
        }
        else if(let[24] == 'f')
        {
         word[f_array[bz]] = commoneng[24];
        }
        else if(let[25] == 'f')
        {
         word[f_array[bz]] = commoneng[25];
        }
     }// end for
     for(int yo = 0; yo < g; yo++)
     {
        if(let[0] == 'g')
        {
         word[g_array[yo]] = commoneng[0];
        }      
        else if(let[1] == 'g')
        {
         word[g_array[yo]] = commoneng[1];
        }
        else if(let[2] == 'g')
        {
         word[g_array[yo]] = commoneng[2];
        }
        else if(let[3] == 'g')
        {
         word[g_array[yo]] = commoneng[3];
        }
        else if(let[4] == 'g')
        {
         word[g_array[yo]] = commoneng[4];
        }
        else if(let[5] == 'g')
        {
         word[g_array[yo]] = commoneng[5];
        }
        else if(let[6] == 'g')
        {
         word[g_array[yo]] = commoneng[6];
        }
        else if(let[7] == 'g')
        {
         word[g_array[yo]] = commoneng[7];
        }
        else if(let[8] == 'g')
        {
         word[g_array[yo]] = commoneng[8];
        }
        else if(let[9] == 'g')
        {
         word[g_array[yo]] = commoneng[9];
        }
        else if(let[10] == 'g')
        {
         word[g_array[yo]] = commoneng[10];
        }
        else if(let[11] == 'g')
        {
         word[g_array[yo]] = commoneng[11];
        }
        else if(let[12] == 'g')
        {
         word[g_array[yo]] = commoneng[12];
        }
        else if(let[13] == 'g')
        {
         word[g_array[yo]] = commoneng[13];
        }
        else if(let[14] == 'g')
        {
         word[g_array[yo]] = commoneng[14];
        }
        else if(let[15] == 'g')
        {
         word[g_array[yo]] = commoneng[15];
        }
        else if(let[16] == 'g')
        {
         word[g_array[yo]] = commoneng[16];
        }
        else if(let[17] == 'g')
        {
         word[g_array[yo]] = commoneng[17];
        }
        else if(let[18] == 'g')
        {
         word[g_array[yo]] = commoneng[18];
        }
        else if(let[19] == 'g')
        {
         word[g_array[yo]] = commoneng[19];
        }
        else if(let[20] == 'g')
        {
         word[g_array[yo]] = commoneng[20];
        }
        else if(let[21] == 'g')
        {
         word[g_array[yo]] = commoneng[21];
        }
        else if(let[22] == 'g')
        {
         word[g_array[yo]] = commoneng[22];
        }
        else if(let[23] == 'g')
        {
         word[g_array[yo]] = commoneng[23];
        }
        else if(let[24] == 'g')
        {
         word[g_array[yo]] = commoneng[24];
        }
        else if(let[25] == 'g')
        {
         word[g_array[yo]] = commoneng[25];
        }
     }// end for
     for(int man = 0; man < h; man++)
     {
        if(let[0] == 'h')
        {
         word[h_array[man]] = commoneng[0];
        }      
        else if(let[1] == 'h')
        {
         word[h_array[man]] = commoneng[1];
        }
        else if(let[2] == 'h')
        {
         word[h_array[man]] = commoneng[2];
        }
        else if(let[3] == 'h')
        {
         word[h_array[man]] = commoneng[3];
        }
        else if(let[4] == 'h')
        {
         word[h_array[man]] = commoneng[4];
        }
        else if(let[5] == 'h')
        {
         word[h_array[man]] = commoneng[5];
        }
        else if(let[6] == 'h')
        {
         word[h_array[man]] = commoneng[6];
        }
        else if(let[7] == 'h')
        {
         word[h_array[man]] = commoneng[7];
        }
        else if(let[8] == 'h')
        {
         word[h_array[man]] = commoneng[8];
        }
        else if(let[9] == 'h')
        {
         word[h_array[man]] = commoneng[9];
        }
        else if(let[10] == 'h')
        {
         word[h_array[man]] = commoneng[10];
        }
        else if(let[11] == 'h')
        {
         word[h_array[man]] = commoneng[11];
        }
        else if(let[12] == 'h')
        {
         word[h_array[man]] = commoneng[12];
        }
        else if(let[13] == 'h')
        {
         word[h_array[man]] = commoneng[13];
        }
        else if(let[14] == 'h')
        {
         word[h_array[man]] = commoneng[14];
        }
        else if(let[15] == 'h')
        {
         word[h_array[man]] = commoneng[15];
        }
        else if(let[16] == 'h')
        {
         word[h_array[man]] = commoneng[16];
        }
        else if(let[17] == 'h')
        {
         word[h_array[man]] = commoneng[17];
        }
        else if(let[18] == 'h')
        {
         word[h_array[man]] = commoneng[18];
        }
        else if(let[19] == 'h')
        {
         word[h_array[man]] = commoneng[19];
        }
        else if(let[20] == 'h')
        {
         word[h_array[man]] = commoneng[20];
        }
        else if(let[21] == 'h')
        {
         word[h_array[man]] = commoneng[21];
        }
        else if(let[22] == 'h')
        {
         word[h_array[man]] = commoneng[22];
        }
        else if(let[23] == 'h')
        {
         word[h_array[man]] = commoneng[23];
        }
        else if(let[24] == 'h')
        {
         word[h_array[man]] = commoneng[24];
        }
        else if(let[25] == 'h')
        {
         word[h_array[man]] = commoneng[25];
        }
     }// end for
     for(int hi = 0; hi < i; hi++)
     {
        if(let[0] == 'i')
        {
         word[i_array[hi]] = commoneng[0];
        }      
        else if(let[1] == 'i')
        {
         word[i_array[hi]] = commoneng[1];
        }
        else if(let[2] == 'i')
        {
         word[i_array[hi]] = commoneng[2];
        }
        else if(let[3] == 'i')
        {
         word[i_array[hi]] = commoneng[3];
        }
        else if(let[4] == 'i')
        {
         word[i_array[hi]] = commoneng[4];
        }
        else if(let[5] == 'i')
        {
         word[i_array[hi]] = commoneng[5];
        }
        else if(let[6] == 'i')
        {
         word[i_array[hi]] = commoneng[6];
        }
        else if(let[7] == 'i')
        {
         word[i_array[hi]] = commoneng[7];
        }
        else if(let[8] == 'i')
        {
         word[i_array[hi]] = commoneng[8];
        }
        else if(let[9] == 'i')
        {
         word[i_array[hi]] = commoneng[9];
        }
        else if(let[10] == 'i')
        {
         word[i_array[hi]] = commoneng[10];
        }
        else if(let[11] == 'i')
        {
         word[i_array[hi]] = commoneng[11];
        }
        else if(let[12] == 'i')
        {
         word[i_array[hi]] = commoneng[12];
        }
        else if(let[13] == 'i')
        {
         word[i_array[hi]] = commoneng[13];
        }
        else if(let[14] == 'i')
        {
         word[i_array[hi]] = commoneng[14];
        }
        else if(let[15] == 'i')
        {
         word[i_array[hi]] = commoneng[15];
        }
        else if(let[16] == 'i')
        {
         word[i_array[hi]] = commoneng[16];
        }
        else if(let[17] == 'i')
        {
         word[i_array[hi]] = commoneng[17];
        }
        else if(let[18] == 'i')
        {
         word[i_array[hi]] = commoneng[18];
        }
        else if(let[19] == 'i')
        {
         word[i_array[hi]] = commoneng[19];
        }
        else if(let[20] == 'i')
        {
         word[i_array[hi]] = commoneng[20];
        }
        else if(let[21] == 'i')
        {
         word[i_array[hi]] = commoneng[21];
        }
        else if(let[22] == 'i')
        {
         word[i_array[hi]] = commoneng[22];
        }
        else if(let[23] == 'i')
        {
         word[i_array[hi]] = commoneng[23];
        }
        else if(let[24] == 'i')
        {
         word[i_array[hi]] = commoneng[24];
        }
        else if(let[25] == 'i')
        {
         word[i_array[hi]] = commoneng[25];
        }
     }// end for
     for(int zt = 0; zt < j; zt++)
     {
        if(let[0] == 'j')
        {
         word[j_array[zt]] = commoneng[0];
        }      
        else if(let[1] == 'j')
        {
         word[j_array[zt]] = commoneng[1];
        }
        else if(let[2] == 'j')
        {
         word[j_array[zt]] = commoneng[2];
        }
        else if(let[3] == 'j')
        {
         word[j_array[zt]] = commoneng[3];
        }
        else if(let[4] == 'j')
        {
         word[j_array[zt]] = commoneng[4];
        }
        else if(let[5] == 'j')
        {
         word[j_array[zt]] = commoneng[5];
        }
        else if(let[6] == 'j')
        {
         word[j_array[zt]] = commoneng[6];
        }
        else if(let[7] == 'j')
        {
         word[j_array[zt]] = commoneng[7];
        }
        else if(let[8] == 'j')
        {
         word[j_array[zt]] = commoneng[8];
        }
        else if(let[9] == 'j')
        {
         word[j_array[zt]] = commoneng[9];
        }
        else if(let[10] == 'j')
        {
         word[j_array[zt]] = commoneng[10];
        }
        else if(let[11] == 'j')
        {
         word[j_array[zt]] = commoneng[11];
        }
        else if(let[12] == 'j')
        {
         word[j_array[zt]] = commoneng[12];
        }
        else if(let[13] == 'j')
        {
         word[j_array[zt]] = commoneng[13];
        }
        else if(let[14] == 'j')
        {
         word[j_array[zt]] = commoneng[14];
        }
        else if(let[15] == 'j')
        {
         word[j_array[zt]] = commoneng[15];
        }
        else if(let[16] == 'j')
        {
         word[j_array[zt]] = commoneng[16];
        }
        else if(let[17] == 'j')
        {
         word[j_array[zt]] = commoneng[17];
        }
        else if(let[18] == 'j')
        {
         word[j_array[zt]] = commoneng[18];
        }
        else if(let[19] == 'j')
        {
         word[j_array[zt]] = commoneng[19];
        }
        else if(let[20] == 'j')
        {
         word[j_array[zt]] = commoneng[20];
        }
        else if(let[21] == 'j')
        {
         word[j_array[zt]] = commoneng[21];
        }
        else if(let[22] == 'j')
        {
         word[j_array[zt]] = commoneng[22];
        }
        else if(let[23] == 'j')
        {
         word[j_array[zt]] = commoneng[23];
        }
        else if(let[24] == 'j')
        {
         word[j_array[zt]] = commoneng[24];
        }
        else if(let[25] == 'j')
        {
         word[j_array[zt]] = commoneng[25];
        }
     }// end for
     for(int vb = 0; vb < k; vb++)
     {
        if(let[0] == 'k')
        {
         word[k_array[vb]] = commoneng[0];
        }      
        else if(let[1] == 'k')
        {
         word[k_array[vb]] = commoneng[1];
        }
        else if(let[2] == 'k')
        {
         word[k_array[vb]] = commoneng[2];
        }
        else if(let[3] == 'k')
        {
         word[k_array[vb]] = commoneng[3];
        }
        else if(let[4] == 'k')
        {
         word[k_array[vb]] = commoneng[4];
        }
        else if(let[5] == 'k')
        {
         word[k_array[vb]] = commoneng[5];
        }
        else if(let[6] == 'k')
        {
         word[k_array[vb]] = commoneng[6];
        }
        else if(let[7] == 'k')
        {
         word[k_array[vb]] = commoneng[7];
        }
        else if(let[8] == 'k')
        {
         word[k_array[vb]] = commoneng[8];
        }
        else if(let[9] == 'k')
        {
         word[k_array[vb]] = commoneng[9];
        }
        else if(let[10] == 'k')
        {
         word[k_array[vb]] = commoneng[10];
        }
        else if(let[11] == 'k')
        {
         word[k_array[vb]] = commoneng[11];
        }
        else if(let[12] == 'k')
        {
         word[k_array[vb]] = commoneng[12];
        }
        else if(let[13] == 'k')
        {
         word[k_array[vb]] = commoneng[13];
        }
        else if(let[14] == 'k')
        {
         word[k_array[vb]] = commoneng[14];
        }
        else if(let[15] == 'k')
        {
         word[k_array[vb]] = commoneng[15];
        }
        else if(let[16] == 'k')
        {
         word[k_array[vb]] = commoneng[16];
        }
        else if(let[17] == 'k')
        {
         word[k_array[vb]] = commoneng[17];
        }
        else if(let[18] == 'k')
        {
         word[k_array[vb]] = commoneng[18];
        }
        else if(let[19] == 'k')
        {
         word[k_array[vb]] = commoneng[19];
        }
        else if(let[20] == 'k')
        {
         word[k_array[vb]] = commoneng[20];
        }
        else if(let[21] == 'k')
        {
         word[k_array[vb]] = commoneng[21];
        }
        else if(let[22] == 'k')
        {
         word[k_array[vb]] = commoneng[22];
        }
        else if(let[23] == 'k')
        {
         word[k_array[vb]] = commoneng[23];
        }
        else if(let[24] == 'k')
        {
         word[k_array[vb]] = commoneng[24];
        }
        else if(let[25] == 'k')
        {
         word[k_array[vb]] = commoneng[25];
        }
     }// end for
     for(int po = 0; po < l; po++)
     {
        if(let[0] == 'l')
        {
         word[l_array[po]] = commoneng[0];
        }      
        else if(let[1] == 'l')
        {
         word[l_array[po]] = commoneng[1];
        }
        else if(let[2] == 'l')
        {
         word[l_array[po]] = commoneng[2];
        }
        else if(let[3] == 'l')
        {
         word[l_array[po]] = commoneng[3];
        }
        else if(let[4] == 'l')
        {
         word[l_array[po]] = commoneng[4];
        }
        else if(let[5] == 'l')
        {
         word[l_array[po]] = commoneng[5];
        }
        else if(let[6] == 'l')
        {
         word[l_array[po]] = commoneng[6];
        }
        else if(let[7] == 'l')
        {
         word[l_array[po]] = commoneng[7];
        }
        else if(let[8] == 'l')
        {
         word[l_array[po]] = commoneng[8];
        }
        else if(let[9] == 'l')
        {
         word[l_array[po]] = commoneng[9];
        }
        else if(let[10] == 'l')
        {
         word[l_array[po]] = commoneng[10];
        }
        else if(let[11] == 'l')
        {
         word[l_array[po]] = commoneng[11];
        }
        else if(let[12] == 'l')
        {
         word[l_array[po]] = commoneng[12];
        }
        else if(let[13] == 'l')
        {
         word[l_array[po]] = commoneng[13];
        }
        else if(let[14] == 'l')
        {
         word[l_array[po]] = commoneng[14];
        }
        else if(let[15] == 'l')
        {
         word[l_array[po]] = commoneng[15];
        }
        else if(let[16] == 'l')
        {
         word[l_array[po]] = commoneng[16];
        }
        else if(let[17] == 'l')
        {
         word[l_array[po]] = commoneng[17];
        }
        else if(let[18] == 'l')
        {
         word[l_array[po]] = commoneng[18];
        }
        else if(let[19] == 'l')
        {
         word[l_array[po]] = commoneng[19];
        }
        else if(let[20] == 'l')
        {
         word[l_array[po]] = commoneng[20];
        }
        else if(let[21] == 'l')
        {
         word[l_array[po]] = commoneng[21];
        }
        else if(let[22] == 'l')
        {
         word[l_array[po]] = commoneng[22];
        }
        else if(let[23] == 'l')
        {
         word[l_array[po]] = commoneng[23];
        }
        else if(let[24] == 'l')
        {
         word[l_array[po]] = commoneng[24];
        }
        else if(let[25] == 'l')
        {
         word[l_array[po]] = commoneng[25];
        }
     }// end for
     for(int of = 0; of < m; of++)
     {
        if(let[0] == 'm')
        {
         word[m_array[of]] = commoneng[0];
        }      
        else if(let[1] == 'm')
        {
         word[m_array[of]] = commoneng[1];
        }
        else if(let[2] == 'm')
        {
         word[m_array[of]] = commoneng[2];
        }
        else if(let[3] == 'm')
        {
         word[m_array[of]] = commoneng[3];
        }
        else if(let[4] == 'm')
        {
         word[m_array[of]] = commoneng[4];
        }
        else if(let[5] == 'm')
        {
         word[m_array[of]] = commoneng[5];
        }
        else if(let[6] == 'm')
        {
         word[m_array[of]] = commoneng[6];
        }
        else if(let[7] == 'm')
        {
         word[m_array[of]] = commoneng[7];
        }
        else if(let[8] == 'm')
        {
         word[m_array[of]] = commoneng[8];
        }
        else if(let[9] == 'm')
        {
         word[m_array[of]] = commoneng[9];
        }
        else if(let[10] == 'm')
        {
         word[m_array[of]] = commoneng[10];
        }
        else if(let[11] == 'm')
        {
         word[m_array[of]] = commoneng[11];
        }
        else if(let[12] == 'm')
        {
         word[m_array[of]] = commoneng[12];
        }
        else if(let[13] == 'm')
        {
         word[m_array[of]] = commoneng[13];
        }
        else if(let[14] == 'm')
        {
         word[m_array[of]] = commoneng[14];
        }
        else if(let[15] == 'm')
        {
         word[m_array[of]] = commoneng[15];
        }
        else if(let[16] == 'm')
        {
         word[m_array[of]] = commoneng[16];
        }
        else if(let[17] == 'm')
        {
         word[m_array[of]] = commoneng[17];
        }
        else if(let[18] == 'm')
        {
         word[m_array[of]] = commoneng[18];
        }
        else if(let[19] == 'm')
        {
         word[m_array[of]] = commoneng[19];
        }
        else if(let[20] == 'm')
        {
         word[m_array[of]] = commoneng[20];
        }
        else if(let[21] == 'm')
        {
         word[m_array[of]] = commoneng[21];
        }
        else if(let[22] == 'm')
        {
         word[m_array[of]] = commoneng[22];
        }
        else if(let[23] == 'm')
        {
         word[m_array[of]] = commoneng[23];
        }
        else if(let[24] == 'm')
        {
         word[m_array[of]] = commoneng[24];
        }
        else if(let[25] == 'm')
        {
         word[m_array[of]] = commoneng[25];
        }
     }// end for
     for(int co = 0; co < n; co++)
     {
        if(let[0] == 'n')
        {
         word[n_array[co]] = commoneng[0];
        }      
        else if(let[1] == 'n')
        {
         word[n_array[co]] = commoneng[1];
        }
        else if(let[2] == 'n')
        {
         word[n_array[co]] = commoneng[2];
        }
        else if(let[3] == 'n')
        {
         word[n_array[co]] = commoneng[3];
        }
        else if(let[4] == 'n')
        {
         word[n_array[co]] = commoneng[4];
        }
        else if(let[5] == 'n')
        {
         word[n_array[co]] = commoneng[5];
        }
        else if(let[6] == 'n')
        {
         word[n_array[co]] = commoneng[6];
        }
        else if(let[7] == 'n')
        {
         word[n_array[co]] = commoneng[7];
        }
        else if(let[8] == 'n')
        {
         word[n_array[co]] = commoneng[8];
        }
        else if(let[9] == 'n')
        {
         word[n_array[co]] = commoneng[9];
        }
        else if(let[10] == 'n')
        {
         word[n_array[co]] = commoneng[10];
        }
        else if(let[11] == 'n')
        {
         word[n_array[co]] = commoneng[11];
        }
        else if(let[12] == 'n')
        {
         word[n_array[co]] = commoneng[12];
        }
        else if(let[13] == 'n')
        {
         word[n_array[co]] = commoneng[13];
        }
        else if(let[14] == 'n')
        {
         word[n_array[co]] = commoneng[14];
        }
        else if(let[15] == 'n')
        {
         word[n_array[co]] = commoneng[15];
        }
        else if(let[16] == 'n')
        {
         word[n_array[co]] = commoneng[16];
        }
        else if(let[17] == 'n')
        {
         word[n_array[co]] = commoneng[17];
        }
        else if(let[18] == 'n')
        {
         word[n_array[co]] = commoneng[18];
        }
        else if(let[19] == 'n')
        {
         word[n_array[co]] = commoneng[19];
        }
        else if(let[20] == 'n')
        {
         word[n_array[co]] = commoneng[20];
        }
        else if(let[21] == 'n')
        {
         word[n_array[co]] = commoneng[21];
        }
        else if(let[22] == 'n')
        {
         word[n_array[co]] = commoneng[22];
        }
        else if(let[23] == 'n')
        {
         word[n_array[co]] = commoneng[23];
        }
        else if(let[24] == 'n')
        {
         word[n_array[co]] = commoneng[24];
        }
        else if(let[25] == 'n')
        {
         word[n_array[co]] = commoneng[25];
        }
     }// end for
     for(int ca = 0; ca < o; ca++)
     {
        if(let[0] == 'o')
        {
         word[o_array[ca]] = commoneng[0];
        }      
        else if(let[1] == 'o')
        {
         word[o_array[ca]] = commoneng[1];
        }
        else if(let[2] == 'o')
        {
         word[o_array[ca]] = commoneng[2];
        }
        else if(let[3] == 'o')
        {
         word[o_array[ca]] = commoneng[3];
        }
        else if(let[4] == 'o')
        {
         word[o_array[ca]] = commoneng[4];
        }
        else if(let[5] == 'o')
        {
         word[o_array[ca]] = commoneng[5];
        }
        else if(let[6] == 'o')
        {
         word[o_array[ca]] = commoneng[6];
        }
        else if(let[7] == 'o')
        {
         word[o_array[ca]] = commoneng[7];
        }
        else if(let[8] == 'o')
        {
         word[o_array[ca]] = commoneng[8];
        }
        else if(let[9] == 'o')
        {
         word[o_array[ca]] = commoneng[9];
        }
        else if(let[10] == 'o')
        {
         word[o_array[ca]] = commoneng[10];
        }
        else if(let[11] == 'o')
        {
         word[o_array[ca]] = commoneng[11];
        }
        else if(let[12] == 'o')
        {
         word[o_array[ca]] = commoneng[12];
        }
        else if(let[13] == 'o')
        {
         word[o_array[ca]] = commoneng[13];
        }
        else if(let[14] == 'o')
        {
         word[o_array[ca]] = commoneng[14];
        }
        else if(let[15] == 'o')
        {
         word[o_array[ca]] = commoneng[15];
        }
        else if(let[16] == 'o')
        {
         word[o_array[ca]] = commoneng[16];
        }
        else if(let[17] == 'o')
        {
         word[o_array[ca]] = commoneng[17];
        }
        else if(let[18] == 'o')
        {
         word[o_array[ca]] = commoneng[18];
        }
        else if(let[19] == 'o')
        {
         word[o_array[ca]] = commoneng[19];
        }
        else if(let[20] == 'o')
        {
         word[o_array[ca]] = commoneng[20];
        }
        else if(let[21] == 'o')
        {
         word[o_array[ca]] = commoneng[21];
        }
        else if(let[22] == 'o')
        {
         word[o_array[ca]] = commoneng[22];
        }
        else if(let[23] == 'o')
        {
         word[o_array[ca]] = commoneng[23];
        }
        else if(let[24] == 'o')
        {
         word[o_array[ca]] = commoneng[24];
        }
        else if(let[25] == 'o')
        {
         word[o_array[ca]] = commoneng[25];
        }
     }// end for
     for(int cu = 0; cu < p; cu++)
     {
        if(let[0] == 'p')
        {
         word[p_array[cu]] = commoneng[0];
        }      
        else if(let[1] == 'p')
        {
         word[p_array[cu]] = commoneng[1];
        }
        else if(let[2] == 'p')
        {
         word[p_array[cu]] = commoneng[2];
        }
        else if(let[3] == 'p')
        {
         word[p_array[cu]] = commoneng[3];
        }
        else if(let[4] == 'p')
        {
         word[p_array[cu]] = commoneng[4];
        }
        else if(let[5] == 'p')
        {
         word[p_array[cu]] = commoneng[5];
        }
        else if(let[6] == 'p')
        {
         word[p_array[cu]] = commoneng[6];
        }
        else if(let[7] == 'p')
        {
         word[p_array[cu]] = commoneng[7];
        }
        else if(let[8] == 'p')
        {
         word[p_array[cu]] = commoneng[8];
        }
        else if(let[9] == 'p')
        {
         word[p_array[cu]] = commoneng[9];
        }
        else if(let[10] == 'p')
        {
         word[p_array[cu]] = commoneng[10];
        }
        else if(let[11] == 'p')
        {
         word[p_array[cu]] = commoneng[11];
        }
        else if(let[12] == 'p')
        {
         word[p_array[cu]] = commoneng[12];
        }
        else if(let[13] == 'p')
        {
         word[p_array[cu]] = commoneng[13];
        }
        else if(let[14] == 'p')
        {
         word[p_array[cu]] = commoneng[14];
        }
        else if(let[15] == 'p')
        {
         word[p_array[cu]] = commoneng[15];
        }
        else if(let[16] == 'p')
        {
         word[p_array[cu]] = commoneng[16];
        }
        else if(let[17] == 'p')
        {
         word[p_array[cu]] = commoneng[17];
        }
        else if(let[18] == 'p')
        {
         word[p_array[cu]] = commoneng[18];
        }
        else if(let[19] == 'p')
        {
         word[p_array[cu]] = commoneng[19];
        }
        else if(let[20] == 'p')
        {
         word[p_array[cu]] = commoneng[20];
        }
        else if(let[21] == 'p')
        {
         word[p_array[cu]] = commoneng[21];
        }
        else if(let[22] == 'p')
        {
         word[p_array[cu]] = commoneng[22];
        }
        else if(let[23] == 'p')
        {
         word[p_array[cu]] = commoneng[23];
        }
        else if(let[24] == 'p')
        {
         word[p_array[cu]] = commoneng[24];
        }
        else if(let[25] == 'p')
        {
         word[p_array[cu]] = commoneng[25];
        }
     }// end for
     for(int ci = 0; ci < q; ci++)
     {
        if(let[0] == 'q')
        {
         word[q_array[ci]] = commoneng[0];
        }      
        else if(let[1] == 'q')
        {
         word[q_array[ci]] = commoneng[1];
        }
        else if(let[2] == 'q')
        {
         word[q_array[ci]] = commoneng[2];
        }
        else if(let[3] == 'q')
        {
         word[q_array[ci]] = commoneng[3];
        }
        else if(let[4] == 'q')
        {
         word[q_array[ci]] = commoneng[4];
        }
        else if(let[5] == 'q')
        {
         word[q_array[ci]] = commoneng[5];
        }
        else if(let[6] == 'q')
        {
         word[q_array[ci]] = commoneng[6];
        }
        else if(let[7] == 'q')
        {
         word[q_array[ci]] = commoneng[7];
        }
        else if(let[8] == 'q')
        {
         word[q_array[ci]] = commoneng[8];
        }
        else if(let[9] == 'q')
        {
         word[q_array[ci]] = commoneng[9];
        }
        else if(let[10] == 'q')
        {
         word[q_array[ci]] = commoneng[10];
        }
        else if(let[11] == 'q')
        {
         word[q_array[ci]] = commoneng[11];
        }
        else if(let[12] == 'q')
        {
         word[q_array[ci]] = commoneng[12];
        }
        else if(let[13] == 'q')
        {
         word[q_array[ci]] = commoneng[13];
        }
        else if(let[14] == 'q')
        {
         word[q_array[ci]] = commoneng[14];
        }
        else if(let[15] == 'q')
        {
         word[q_array[ci]] = commoneng[15];
        }
        else if(let[16] == 'q')
        {
         word[q_array[ci]] = commoneng[16];
        }
        else if(let[17] == 'q')
        {
         word[q_array[ci]] = commoneng[17];
        }
        else if(let[18] == 'q')
        {
         word[q_array[ci]] = commoneng[18];
        }
        else if(let[19] == 'q')
        {
         word[q_array[ci]] = commoneng[19];
        }
        else if(let[20] == 'q')
        {
         word[q_array[ci]] = commoneng[20];
        }
        else if(let[21] == 'q')
        {
         word[q_array[ci]] = commoneng[21];
        }
        else if(let[22] == 'q')
        {
         word[q_array[ci]] = commoneng[22];
        }
        else if(let[23] == 'q')
        {
         word[q_array[ci]] = commoneng[23];
        }
        else if(let[24] == 'q')
        {
         word[q_array[ci]] = commoneng[24];
        }
        else if(let[25] == 'q')
        {
         word[q_array[ci]] = commoneng[25];
        }
     }// end for
     for(int ce = 0; ce < r; ce++)
     {
        if(let[0] == 'r')
        {
         word[r_array[ce]] = commoneng[0];
        }      
        else if(let[1] == 'r')
        {
         word[r_array[ce]] = commoneng[1];
        }
        else if(let[2] == 'r')
        {
         word[r_array[ce]] = commoneng[2];
        }
        else if(let[3] == 'r')
        {
         word[r_array[ce]] = commoneng[3];
        }
        else if(let[4] == 'r')
        {
         word[r_array[ce]] = commoneng[4];
        }
        else if(let[5] == 'r')
        {
         word[r_array[ce]] = commoneng[5];
        }
        else if(let[6] == 'r')
        {
         word[r_array[ce]] = commoneng[6];
        }
        else if(let[7] == 'r')
        {
         word[r_array[ce]] = commoneng[7];
        }
        else if(let[8] == 'r')
        {
         word[r_array[ce]] = commoneng[8];
        }
        else if(let[9] == 'r')
        {
         word[r_array[ce]] = commoneng[9];
        }
        else if(let[10] == 'r')
        {
         word[r_array[ce]] = commoneng[10];
        }
        else if(let[11] == 'r')
        {
         word[r_array[ce]] = commoneng[11];
        }
        else if(let[12] == 'r')
        {
         word[r_array[ce]] = commoneng[12];
        }
        else if(let[13] == 'r')
        {
         word[r_array[ce]] = commoneng[13];
        }
        else if(let[14] == 'r')
        {
         word[r_array[ce]] = commoneng[14];
        }
        else if(let[15] == 'r')
        {
         word[r_array[ce]] = commoneng[15];
        }
        else if(let[16] == 'r')
        {
         word[r_array[ce]] = commoneng[16];
        }
        else if(let[17] == 'r')
        {
         word[r_array[ce]] = commoneng[17];
        }
        else if(let[18] == 'r')
        {
         word[r_array[ce]] = commoneng[18];
        }
        else if(let[19] == 'r')
        {
         word[r_array[ce]] = commoneng[19];
        }
        else if(let[20] == 'r')
        {
         word[r_array[ce]] = commoneng[20];
        }
        else if(let[21] == 'r')
        {
         word[r_array[ce]] = commoneng[21];
        }
        else if(let[22] == 'r')
        {
         word[r_array[ce]] = commoneng[22];
        }
        else if(let[23] == 'r')
        {
         word[r_array[ce]] = commoneng[23];
        }
        else if(let[24] == 'r')
        {
         word[r_array[ce]] = commoneng[24];
        }
        else if(let[25] == 'r')
        {
         word[r_array[ce]] = commoneng[25];
        }
     }// end for
     for(int pa = 0; pa < s; pa++)
     {
        if(let[0] == 's')
        {
         word[s_array[pa]] = commoneng[0];
        }      
        else if(let[1] == 's')
        {
         word[s_array[pa]] = commoneng[1];
        }
        else if(let[2] == 's')
        {
         word[s_array[pa]] = commoneng[2];
        }
        else if(let[3] == 's')
        {
         word[s_array[pa]] = commoneng[3];
        }
        else if(let[4] == 's')
        {
         word[s_array[pa]] = commoneng[4];
        }
        else if(let[5] == 's')
        {
         word[s_array[pa]] = commoneng[5];
        }
        else if(let[6] == 's')
        {
         word[s_array[pa]] = commoneng[6];
        }
        else if(let[7] == 's')
        {
         word[s_array[pa]] = commoneng[7];
        }
        else if(let[8] == 's')
        {
         word[s_array[pa]] = commoneng[8];
        }
        else if(let[9] == 's')
        {
         word[s_array[pa]] = commoneng[9];
        }
        else if(let[10] == 's')
        {
         word[s_array[pa]] = commoneng[10];
        }
        else if(let[11] == 's')
        {
         word[s_array[pa]] = commoneng[11];
        }
        else if(let[12] == 's')
        {
         word[s_array[pa]] = commoneng[12];
        }
        else if(let[13] == 's')
        {
         word[s_array[pa]] = commoneng[13];
        }
        else if(let[14] == 's')
        {
         word[s_array[pa]] = commoneng[14];
        }
        else if(let[15] == 's')
        {
         word[s_array[pa]] = commoneng[15];
        }
        else if(let[16] == 's')
        {
         word[s_array[pa]] = commoneng[16];
        }
        else if(let[17] == 's')
        {
         word[s_array[pa]] = commoneng[17];
        }
        else if(let[18] == 's')
        {
         word[s_array[pa]] = commoneng[18];
        }
        else if(let[19] == 's')
        {
         word[s_array[pa]] = commoneng[19];
        }
        else if(let[20] == 's')
        {
         word[s_array[pa]] = commoneng[20];
        }
        else if(let[21] == 's')
        {
         word[s_array[pa]] = commoneng[21];
        }
        else if(let[22] == 's')
        {
         word[s_array[pa]] = commoneng[22];
        }
        else if(let[23] == 's')
        {
         word[s_array[pa]] = commoneng[23];
        }
        else if(let[24] == 's')
        {
         word[s_array[pa]] = commoneng[24];
        }
        else if(let[25] == 's')
        {
         word[s_array[pa]] = commoneng[25];
        }
     }// end for
     for(int pe = 0; pe < t; pe++)
     {
        if(let[0] == 't')
        {
         word[t_array[pe]] = commoneng[0];
        }      
        else if(let[1] == 't')
        {
         word[t_array[pe]] = commoneng[1];
        }
        else if(let[2] == 't')
        {
         word[t_array[pe]] = commoneng[2];
        }
        else if(let[3] == 't')
        {
         word[t_array[pe]] = commoneng[3];
        }
        else if(let[4] == 't')
        {
         word[t_array[pe]] = commoneng[4];
        }
        else if(let[5] == 't')
        {
         word[t_array[pe]] = commoneng[5];
        }
        else if(let[6] == 't')
        {
         word[t_array[pe]] = commoneng[6];
        }
        else if(let[7] == 't')
        {
         word[t_array[pe]] = commoneng[7];
        }
        else if(let[8] == 't')
        {
         word[t_array[pe]] = commoneng[8];
        }
        else if(let[9] == 't')
        {
         word[t_array[pe]] = commoneng[9];
        }
        else if(let[10] == 't')
        {
         word[t_array[pe]] = commoneng[10];
        }
        else if(let[11] == 't')
        {
         word[t_array[pe]] = commoneng[11];
        }
        else if(let[12] == 't')
        {
         word[t_array[pe]] = commoneng[12];
        }
        else if(let[13] == 't')
        {
         word[t_array[pe]] = commoneng[13];
        }
        else if(let[14] == 't')
        {
         word[t_array[pe]] = commoneng[14];
        }
        else if(let[15] == 't')
        {
         word[t_array[pe]] = commoneng[15];
        }
        else if(let[16] == 't')
        {
         word[t_array[pe]] = commoneng[16];
        }
        else if(let[17] == 't')
        {
         word[t_array[pe]] = commoneng[17];
        }
        else if(let[18] == 't')
        {
         word[t_array[pe]] = commoneng[18];
        }
        else if(let[19] == 't')
        {
         word[t_array[pe]] = commoneng[19];
        }
        else if(let[20] == 't')
        {
         word[t_array[pe]] = commoneng[20];
        }
        else if(let[21] == 't')
        {
         word[t_array[pe]] = commoneng[21];
        }
        else if(let[22] == 't')
        {
         word[t_array[pe]] = commoneng[22];
        }
        else if(let[23] == 't')
        {
         word[t_array[pe]] = commoneng[23];
        }
        else if(let[24] == 't')
        {
         word[t_array[pe]] = commoneng[24];
        }
        else if(let[25] == 't')
        {
         word[t_array[pe]] = commoneng[25];
        }
     }// end for
     for(int we = 0; we < u; we++)
     {
        if(let[0] == 'u')
        {
         word[u_array[we]] = commoneng[0];
        }      
        else if(let[1] == 'u')
        {
         word[u_array[we]] = commoneng[1];
        }
        else if(let[2] == 'u')
        {
         word[u_array[we]] = commoneng[2];
        }
        else if(let[3] == 'u')
        {
         word[u_array[we]] = commoneng[3];
        }
        else if(let[4] == 'u')
        {
         word[u_array[we]] = commoneng[4];
        }
        else if(let[5] == 'u')
        {
         word[u_array[we]] = commoneng[5];
        }
        else if(let[6] == 'u')
        {
         word[u_array[we]] = commoneng[6];
        }
        else if(let[7] == 'u')
        {
         word[u_array[we]] = commoneng[7];
        }
        else if(let[8] == 'u')
        {
         word[u_array[we]] = commoneng[8];
        }
        else if(let[9] == 'u')
        {
         word[u_array[we]] = commoneng[9];
        }
        else if(let[10] == 'u')
        {
         word[u_array[we]] = commoneng[10];
        }
        else if(let[11] == 'u')
        {
         word[u_array[we]] = commoneng[11];
        }
        else if(let[12] == 'u')
        {
         word[u_array[we]] = commoneng[12];
        }
        else if(let[13] == 'u')
        {
         word[u_array[we]] = commoneng[13];
        }
        else if(let[14] == 'u')
        {
         word[u_array[we]] = commoneng[14];
        }
        else if(let[15] == 'u')
        {
         word[u_array[we]] = commoneng[15];
        }
        else if(let[16] == 'u')
        {
         word[u_array[we]] = commoneng[16];
        }
        else if(let[17] == 'u')
        {
         word[u_array[we]] = commoneng[17];
        }
        else if(let[18] == 'u')
        {
         word[u_array[we]] = commoneng[18];
        }
        else if(let[19] == 'u')
        {
         word[u_array[we]] = commoneng[19];
        }
        else if(let[20] == 'u')
        {
         word[u_array[we]] = commoneng[20];
        }
        else if(let[21] == 'u')
        {
         word[u_array[we]] = commoneng[21];
        }
        else if(let[22] == 'u')
        {
         word[u_array[we]] = commoneng[22];
        }
        else if(let[23] == 'u')
        {
         word[u_array[we]] = commoneng[23];
        }
        else if(let[24] == 'u')
        {
         word[u_array[we]] = commoneng[24];
        }
        else if(let[25] == 'u')
        {
         word[u_array[we]] = commoneng[25];
        }
     }// end for
     for(int za = 0; za < v; za++)
     {
        if(let[0] == 'v')
        {
         word[v_array[za]] = commoneng[0];
        }      
        else if(let[1] == 'v')
        {
         word[v_array[za]] = commoneng[1];
        }
        else if(let[2] == 'v')
        {
         word[v_array[za]] = commoneng[2];
        }
        else if(let[3] == 'v')
        {
         word[v_array[za]] = commoneng[3];
        }
        else if(let[4] == 'v')
        {
         word[v_array[za]] = commoneng[4];
        }
        else if(let[5] == 'v')
        {
         word[v_array[za]] = commoneng[5];
        }
        else if(let[6] == 'v')
        {
         word[v_array[za]] = commoneng[6];
        }
        else if(let[7] == 'v')
        {
         word[v_array[za]] = commoneng[7];
        }
        else if(let[8] == 'v')
        {
         word[v_array[za]] = commoneng[8];
        }
        else if(let[9] == 'v')
        {
         word[v_array[za]] = commoneng[9];
        }
        else if(let[10] == 'v')
        {
         word[v_array[za]] = commoneng[10];
        }
        else if(let[11] == 'v')
        {
         word[v_array[za]] = commoneng[11];
        }
        else if(let[12] == 'v')
        {
         word[v_array[za]] = commoneng[12];
        }
        else if(let[13] == 'v')
        {
         word[v_array[za]] = commoneng[13];
        }
        else if(let[14] == 'v')
        {
         word[v_array[za]] = commoneng[14];
        }
        else if(let[15] == 'v')
        {
         word[v_array[za]] = commoneng[15];
        }
        else if(let[16] == 'v')
        {
         word[v_array[za]] = commoneng[16];
        }
        else if(let[17] == 'v')
        {
         word[v_array[za]] = commoneng[17];
        }
        else if(let[18] == 'v')
        {
         word[v_array[za]] = commoneng[18];
        }
        else if(let[19] == 'v')
        {
         word[v_array[za]] = commoneng[19];
        }
        else if(let[20] == 'v')
        {
         word[v_array[za]] = commoneng[20];
        }
        else if(let[21] == 'v')
        {
         word[v_array[za]] = commoneng[21];
        }
        else if(let[22] == 'v')
        {
         word[v_array[za]] = commoneng[22];
        }
        else if(let[23] == 'v')
        {
         word[v_array[za]] = commoneng[23];
        }
        else if(let[24] == 'v')
        {
         word[v_array[za]] = commoneng[24];
        }
        else if(let[25] == 'v')
        {
         word[v_array[za]] = commoneng[25];
        }
     }// end for
     for(int ut = 0; ut < w; ut++)
     {
        if(let[0] == 'w')
        {
         word[w_array[ut]] = commoneng[0];
        }      
        else if(let[1] == 'w')
        {
         word[w_array[ut]] = commoneng[1];
        }
        else if(let[2] == 'w')
        {
         word[w_array[ut]] = commoneng[2];
        }
        else if(let[3] == 'w')
        {
         word[w_array[ut]] = commoneng[3];
        }
        else if(let[4] == 'w')
        {
         word[w_array[ut]] = commoneng[4];
        }
        else if(let[5] == 'w')
        {
         word[w_array[ut]] = commoneng[5];
        }
        else if(let[6] == 'w')
        {
         word[w_array[ut]] = commoneng[6];
        }
        else if(let[7] == 'w')
        {
         word[w_array[ut]] = commoneng[7];
        }
        else if(let[8] == 'w')
        {
         word[w_array[ut]] = commoneng[8];
        }
        else if(let[9] == 'w')
        {
         word[w_array[ut]] = commoneng[9];
        }
        else if(let[10] == 'w')
        {
         word[w_array[ut]] = commoneng[10];
        }
        else if(let[11] == 'w')
        {
         word[w_array[ut]] = commoneng[11];
        }
        else if(let[12] == 'w')
        {
         word[w_array[ut]] = commoneng[12];
        }
        else if(let[13] == 'w')
        {
         word[w_array[ut]] = commoneng[13];
        }
        else if(let[14] == 'w')
        {
         word[w_array[ut]] = commoneng[14];
        }
        else if(let[15] == 'w')
        {
         word[w_array[ut]] = commoneng[15];
        }
        else if(let[16] == 'w')
        {
         word[w_array[ut]] = commoneng[16];
        }
        else if(let[17] == 'w')
        {
         word[w_array[ut]] = commoneng[17];
        }
        else if(let[18] == 'w')
        {
         word[w_array[ut]] = commoneng[18];
        }
        else if(let[19] == 'w')
        {
         word[w_array[ut]] = commoneng[19];
        }
        else if(let[20] == 'w')
        {
         word[w_array[ut]] = commoneng[20];
        }
        else if(let[21] == 'w')
        {
         word[w_array[ut]] = commoneng[21];
        }
        else if(let[22] == 'w')
        {
         word[w_array[ut]] = commoneng[22];
        }
        else if(let[23] == 'w')
        {
         word[w_array[ut]] = commoneng[23];
        }
        else if(let[24] == 'w')
        {
         word[w_array[ut]] = commoneng[24];
        }
        else if(let[25] == 'w')
        {
         word[w_array[ut]] = commoneng[25];
        }
     }// end for
     for(int et = 0; et < x; et++)
     {
        if(let[0] == 'x')
        {
         word[x_array[et]] = commoneng[0];
        }      
        else if(let[1] == 'x')
        {
         word[x_array[et]] = commoneng[1];
        }
        else if(let[2] == 'x')
        {
         word[x_array[et]] = commoneng[2];
        }
        else if(let[3] == 'x')
        {
         word[x_array[et]] = commoneng[3];
        }
        else if(let[4] == 'x')
        {
         word[x_array[et]] = commoneng[4];
        }
        else if(let[5] == 'x')
        {
         word[x_array[et]] = commoneng[5];
        }
        else if(let[6] == 'x')
        {
         word[x_array[et]] = commoneng[6];
        }
        else if(let[7] == 'x')
        {
         word[x_array[et]] = commoneng[7];
        }
        else if(let[8] == 'x')
        {
         word[x_array[et]] = commoneng[8];
        }
        else if(let[9] == 'x')
        {
         word[x_array[et]] = commoneng[9];
        }
        else if(let[10] == 'x')
        {
         word[x_array[et]] = commoneng[10];
        }
        else if(let[11] == 'x')
        {
         word[x_array[et]] = commoneng[11];
        }
        else if(let[12] == 'x')
        {
         word[x_array[et]] = commoneng[12];
        }
        else if(let[13] == 'x')
        {
         word[x_array[et]] = commoneng[13];
        }
        else if(let[14] == 'x')
        {
         word[x_array[et]] = commoneng[14];
        }
        else if(let[15] == 'x')
        {
         word[x_array[et]] = commoneng[15];
        }
        else if(let[16] == 'x')
        {
         word[x_array[et]] = commoneng[16];
        }
        else if(let[17] == 'x')
        {
         word[x_array[et]] = commoneng[17];
        }
        else if(let[18] == 'x')
        {
         word[x_array[et]] = commoneng[18];
        }
        else if(let[19] == 'x')
        {
         word[x_array[et]] = commoneng[19];
        }
        else if(let[20] == 'x')
        {
         word[x_array[et]] = commoneng[20];
        }
        else if(let[21] == 'x')
        {
         word[x_array[et]] = commoneng[21];
        }
        else if(let[22] == 'x')
        {
         word[x_array[et]] = commoneng[22];
        }
        else if(let[23] == 'x')
        {
         word[x_array[et]] = commoneng[23];
        }
        else if(let[24] == 'x')
        {
         word[x_array[et]] = commoneng[24];
        }
        else if(let[25] == 'x')
        {
         word[x_array[et]] = commoneng[25];
        }
     }// end for
     for(int mo = 0; mo < y; mo++)
     {
        if(let[0] == 'y')
        {
         word[y_array[mo]] = commoneng[0];
        }      
        else if(let[1] == 'y')
        {
         word[y_array[mo]] = commoneng[1];
        }
        else if(let[2] == 'y')
        {
         word[y_array[mo]] = commoneng[2];
        }
        else if(let[3] == 'y')
        {
         word[y_array[mo]] = commoneng[3];
        }
        else if(let[4] == 'y')
        {
         word[y_array[mo]] = commoneng[4];
        }
        else if(let[5] == 'y')
        {
         word[y_array[mo]] = commoneng[5];
        }
        else if(let[6] == 'y')
        {
         word[y_array[mo]] = commoneng[6];
        }
        else if(let[7] == 'y')
        {
         word[y_array[mo]] = commoneng[7];
        }
        else if(let[8] == 'y')
        {
         word[y_array[mo]] = commoneng[8];
        }
        else if(let[9] == 'y')
        {
         word[y_array[mo]] = commoneng[9];
        }
        else if(let[10] == 'y')
        {
         word[y_array[mo]] = commoneng[10];
        }
        else if(let[11] == 'y')
        {
         word[y_array[mo]] = commoneng[11];
        }
        else if(let[12] == 'y')
        {
         word[y_array[mo]] = commoneng[12];
        }
        else if(let[13] == 'y')
        {
         word[y_array[mo]] = commoneng[13];
        }
        else if(let[14] == 'y')
        {
         word[y_array[mo]] = commoneng[14];
        }
        else if(let[15] == 'y')
        {
         word[y_array[mo]] = commoneng[15];
        }
        else if(let[16] == 'y')
        {
         word[y_array[mo]] = commoneng[16];
        }
        else if(let[17] == 'y')
        {
         word[y_array[mo]] = commoneng[17];
        }
        else if(let[18] == 'y')
        {
         word[y_array[mo]] = commoneng[18];
        }
        else if(let[19] == 'y')
        {
         word[y_array[mo]] = commoneng[19];
        }
        else if(let[20] == 'y')
        {
         word[y_array[mo]] = commoneng[20];
        }
        else if(let[21] == 'y')
        {
         word[y_array[mo]] = commoneng[21];
        }
        else if(let[22] == 'y')
        {
         word[y_array[mo]] = commoneng[22];
        }
        else if(let[23] == 'y')
        {
         word[y_array[mo]] = commoneng[23];
        }
        else if(let[24] == 'y')
        {
         word[y_array[mo]] = commoneng[24];
        }
        else if(let[25] == 'y')
        {
         word[y_array[mo]] = commoneng[25];
        }
     }// end for
     for(int me = 0; me < z; me++)
     {
        if(let[0] == 'z')
        {
         word[z_array[me]] = commoneng[0];
        }      
        else if(let[1] == 'z')
        {
         word[z_array[me]] = commoneng[1];
        }
        else if(let[2] == 'z')
        {
         word[z_array[me]] = commoneng[2];
        }
        else if(let[3] == 'z')
        {
         word[z_array[me]] = commoneng[3];
        }
        else if(let[4] == 'z')
        {
         word[z_array[me]] = commoneng[4];
        }
        else if(let[5] == 'z')
        {
         word[z_array[me]] = commoneng[5];
        }
        else if(let[6] == 'z')
        {
         word[z_array[me]] = commoneng[6];
        }
        else if(let[7] == 'z')
        {
         word[z_array[me]] = commoneng[7];
        }
        else if(let[8] == 'z')
        {
         word[z_array[me]] = commoneng[8];
        }
        else if(let[9] == 'z')
        {
         word[z_array[me]] = commoneng[9];
        }
        else if(let[10] == 'z')
        {
         word[z_array[me]] = commoneng[10];
        }
        else if(let[11] == 'z')
        {
         word[z_array[me]] = commoneng[11];
        }
        else if(let[12] == 'z')
        {
         word[z_array[me]] = commoneng[12];
        }
        else if(let[13] == 'z')
        {
         word[z_array[me]] = commoneng[13];
        }
        else if(let[14] == 'z')
        {
         word[z_array[me]] = commoneng[14];
        }
        else if(let[15] == 'z')
        {
         word[z_array[me]] = commoneng[15];
        }
        else if(let[16] == 'z')
        {
         word[z_array[me]] = commoneng[16];
        }
        else if(let[17] == 'z')
        {
         word[z_array[me]] = commoneng[17];
        }
        else if(let[18] == 'z')
        {
         word[z_array[me]] = commoneng[18];
        }
        else if(let[19] == 'z')
        {
         word[z_array[me]] = commoneng[19];
        }
        else if(let[20] == 'z')
        {
         word[z_array[me]] = commoneng[20];
        }
        else if(let[21] == 'z')
        {
         word[z_array[me]] = commoneng[21];
        }
        else if(let[22] == 'z')
        {
         word[z_array[me]] = commoneng[22];
        }
        else if(let[23] == 'z')
        {
         word[z_array[me]] = commoneng[23];
        }
        else if(let[24] == 'z')
        {
         word[z_array[me]] = commoneng[24];
        }
        else if(let[25] == 'z')
        {
         word[z_array[me]] = commoneng[25];
        }
     }// end for

       
     for(int boo = 0; boo < length; boo++)
     {
             cout<< word[boo];   // outputs the newly decrypted word     
     }
     
 cout << endl << endl<< "Is this right?\n If not, enter 1 to try again.\n=> ";
 cin >> response;// allows the user to end the loop or continue
}while(response==1);// end while

}// end decrypt function


int main()
{
    string word;
    int length;
    cout << "Enter the message:\n=> ";
    getline(cin, word); // gets word from user input, stops at \n rather than at a space
    length = word.length();// gets length   
    
    decrypt(length, word);
    
}// end main







